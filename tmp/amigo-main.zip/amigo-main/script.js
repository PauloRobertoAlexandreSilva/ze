const video = document.getElementById('video');
const canvas = document.getElementById('overlay');
const msgBox = document.getElementById('message-box');
const battText = document.getElementById('batt-level');
const faceContainer = document.getElementById('robot-face');
const body = document.getElementById('main-screen');
const lp = document.getElementById('lp');
const rp = document.getElementById('rp');

let affinity = 50;
let isAngry = false;

// --- LÓGICA DE FÚRIA (CONTADOR DE TAPAS) ---
let slapCount = 0;
let lastSlapTime = 0;
let slapResetTimer;

// --- LÓGICA DE INTERAÇÃO (TAPA vs CARINHO) ---
let startX, startY;
const screen = document.getElementById('main-screen');

async function updateBattery() {
    try {
        if ('getBattery' in navigator) {
            const battery = await navigator.getBattery();
            
            const refresh = () => {
                const level = Math.round(battery.level * 100);
                battText.innerText = level + "%";
                console.log("Bateria atualizada:", level);
                
                if (level < 20 && !battery.charging) {
                    speak("Estou com fome. Me conecte ao carregador.");
                }
            };

            // Ouvir mudanças
            battery.addEventListener('levelchange', refresh);
            battery.addEventListener('chargingchange', refresh);
            refresh(); // Chamada inicial
        } else {
            // Fallback para navegadores que não suportam (iOS/Safari)
            battText.innerText = "Simulado (85%)";
            console.warn("Battery API não suportada neste navegador.");
        }
    } catch (err) {
        battText.innerText = "Erro no Sensor";
        console.error("Erro ao acessar bateria:", err);
    }
}

screen.addEventListener('touchstart', (e) => {
    if (isAngry) return; // Não interage enquanto atira
    startX = e.touches[0].clientX;
    startY = e.touches[0].clientY;
});

screen.addEventListener('touchend', (e) => {
    if (isAngry) return;
    let endX = e.changedTouches[0].clientX;
    let endY = e.changedTouches[0].clientY;

    let distance = Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));

    if (distance > 40) {
        // CARINHO
        updateAffinity(5);
        msgBox.innerText = "Isso é bom.";
        speak("Isso é bom.");
        slapCount = 0; // Reseta raiva
    } else {
        // TAPA (TOQUE SECO)
        handleSlap();
    }
});

function handleSlap() {
    const now = Date.now();
    updateAffinity(-8);

    // Verifica se o tapa foi rápido (menos de 800ms desde o último)
    if (now - lastSlapTime < 800) {
        slapCount++;
    } else {
        slapCount = 1; // Reinicia contador se demorou muito
    }
    lastSlapTime = now;

    msgBox.innerText = `não me bata (${slapCount}/5)`;
    speak("o que você está fazendo?");

    // Limiar de Fúria atingido
    if (slapCount >= 5) {
        activateGatlingMode();
    }

    // Reseta o contador se ficar 3 segundos sem apanhar
    clearTimeout(slapResetTimer);
    slapResetTimer = setTimeout(() => slapCount = 0, 3000);
}

function activateGatlingMode() {
    isAngry = true;
    slapCount = 0;
    
    faceContainer.classList.add('angry-mode');
    body.classList.add('firing'); // Inicia tremor
    
    msgBox.innerText = "MODO DE DEFESA ATIVADO.";
    speak("Protocolo de retaliação iniciado. Adeus, humano.");

    // Simulação de som de metralhadora (TTS rápido repetido ou oscilador)
    const fireSound = setInterval(() => {
        if ('speechSynthesis' in window) {
            const ut = new SpeechSynthesisUtterance("tá");
            ut.rate = 10; // Muito rápido
            ut.pitch = 0.1; // Grave
            ut.volume = 0.5;
            window.speechSynthesis.speak(ut);
        }
    }, 50);

    // Volta ao normal depois de 5 segundos
    setTimeout(() => {
        clearInterval(fireSound);
        isAngry = false;
        faceContainer.classList.remove('angry-mode');
        body.classList.remove('firing');
        msgBox.innerText = "Espero que tenha aprendido.";
        speak("Não me toque novamente.");
        updateAffinity(20); // Medo aumenta a afinidade "forçada"
    }, 5000);
}

function updateAffinity(value) {
    affinity = Math.max(0, Math.min(100, affinity + value));
    document.getElementById('affinity-level').innerText = affinity;
}

// --- LÓGICA DE IA E SENSORES (INALTERADA) ---

async function checkFaceApi() {
    await updateBattery();

    if (typeof faceapi !== 'undefined') {
        await loadModels();
    } else {
        setTimeout(checkFaceApi, 500);
    }
}

async function loadModels() {
    // URL raw para evitar problemas de CORS local no Live Server
    const MODEL_URL = 'https://raw.githubusercontent.com/vladmandic/face-api/master/model/';
    await faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL);
    await faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL);
    msgBox.innerText = "Modo Olhar Ativado.";
    startVideo();
}

function startVideo() {
    navigator.mediaDevices.getUserMedia({ video: {} })
        .then(stream => video.srcObject = stream)
        .catch(() => msgBox.innerText = "Erro na Câmera.");
}

function speak(text) {
    if (window.speechSynthesis.speaking) window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'pt-BR';
    window.speechSynthesis.speak(utterance);
}

// Loop de Visão
video.addEventListener('play', () => {
    const displaySize = { width: video.offsetWidth, height: video.offsetHeight };
    faceapi.matchDimensions(canvas, displaySize);

    setInterval(async () => {
        // Não rastreia o rosto se estiver atirando (foco na arma)
        if (isAngry) return;

        const detections = await faceapi.detectAllFaces(video, new faceapi.TinyFaceDetectorOptions()).withFaceLandmarks();
        
        if (detections.length > 0) {
            const landmarks = detections[0].landmarks;
            const nose = landmarks.getNose()[0];
            const relX = (nose.x / video.videoWidth) - 0.5;
            const relY = (nose.y / video.videoHeight) - 0.5;
            
            [lp, rp].forEach(p => {
                p.style.transform = `translate(calc(-50% + ${relX * 60}px), calc(-50% + ${relY * 60}px))`;
            });
        }
    }, 150);
});

checkFaceApi();
