# amigo
um amigo virtual


criar um webapp no estilo do tamagochi. utilizando câmera e sensores do smartphone para criar uma interação com usuário para todas as idades, utilizando texto para voz, reconhecimento facial para que a aplicação saiba quando o usuário está presente. na interface deve mostrar 2 olhos como o "robot looi". deve mostrar também a visão da câmera com reconhecimento dos olhos, nariz e boca do usário. os olhos devem acompanhar o usuário. no topo deve mostrar alguns status. vamos começar com o nível de bateria como se fosse a fome, com um ícone correspondente e o percentual de satisfação. se o nível da bateria estiver baixo a aplicação deve falar que está com fome. estou utilizando vs code com live server. quero colocar outra interação. seria de afinidade. se o usuário deslizar o dedo na tela aumenta a afinidade, se somente tocar na tela, seria como se fosse um tapa e a afinidade diminui deixando o aplicativo triste. se puder mostre os olhos tristes
